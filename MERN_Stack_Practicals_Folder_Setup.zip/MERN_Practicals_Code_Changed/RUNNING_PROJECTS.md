# MERN Stack Practicals — Source Code

Each Practical folder contains source files arranged into project folders, rather than code pasted into text files.

## Run a React practical
Open a terminal inside the relevant React folder (or `client` folder for full-stack projects), then run `npm install` and `npm run dev`.

## Run a backend practical
Open a terminal inside the backend folder, run `npm install`, configure `.env` from `.env.example` when present, then run `npm run dev`.

## Full-stack projects
For Practicals 10, 11 and 13, start the server and client in separate terminals. Set `MONGO_URI` in `server/.env` to your own MongoDB connection string. Never share real credentials.

For Practical 12, start the socket server and the React client in separate terminals.

Some examples use in-memory data or simplified CRUD flows for learning. Review and test each project before submission.

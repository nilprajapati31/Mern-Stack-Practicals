import {useState} from 'react';
export default function App(){const [student,setStudent]=useState('Neel');const [count,setCount]=useState(0);return <main className="card"><h1>Props and State</h1><Student name={student} count={count}/><input value={student} onChange={e=>setStudent(e.target.value)} placeholder="Student name"/><button onClick={()=>setCount(c=>c+1)}>Increase marks: {count}</button></main>}
function Student({name,count}){return <section><h2>Hello, {name||'Student'}</h2><p>Points: {count}</p></section>}

const mongoose=require('mongoose');module.exports=mongoose.model('Item',new mongoose.Schema({title:{type:String,required:true},description:{type:String,default:''}},{timestamps:true}));

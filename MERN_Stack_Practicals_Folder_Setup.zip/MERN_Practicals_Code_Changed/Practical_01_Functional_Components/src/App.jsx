import Header from './components/Header.jsx';
import LearnerCard from './components/LearnerCard.jsx';
import Footer from './components/Footer.jsx';
export default function App(){return <><Header/><main><LearnerCard name="Aarav" course="MSc CA & IT" semester={1}/><LearnerCard name="Diya" course="MSc CA & IT" semester={1}/></main><Footer/></>}

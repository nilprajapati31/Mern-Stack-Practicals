export default function Footer(){return <footer className="card">© 2026 Student Portal</footer>

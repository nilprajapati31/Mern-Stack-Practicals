export default function Header(){return <header className="card"><h1>Student Portal</h1><p>Reusable React components</p></header>}

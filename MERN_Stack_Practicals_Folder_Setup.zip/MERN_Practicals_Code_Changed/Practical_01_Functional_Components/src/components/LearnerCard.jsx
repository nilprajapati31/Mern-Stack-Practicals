export default function LearnerCard({name,course,semester}){return <section className="card"><h2>{name}</h2><p>Course: {course}</p><p>Semester: {semester}</p></section>}
